# Link do figmy
https://www.figma.com/file/qrOTEMdeuLLgtlgIsmjJUU/TranquilTravels?type=design&node-id=0%3A1&mode=design&t=R3yCPOkwk9AO8llX-1

W figmie znajdziecie zadanie domowe, mockupy i kilka UXowych wskazówek na przyszłość :)
